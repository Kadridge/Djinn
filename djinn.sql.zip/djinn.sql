-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Dim 15 Juillet 2012 à 11:09
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `djinn`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `post_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` VALUES(3, 'audio', 'audio', 2);
INSERT INTO `categories` VALUES(4, 'video', 'video', 1);

-- --------------------------------------------------------

--
-- Structure de la table `medias`
--

CREATE TABLE `medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'image',
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Contenu de la table `medias`
--

INSERT INTO `medias` VALUES(26, '', '2012/07/wallpaper-3.jpg', 14, 'image');

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `type` varchar(15) NOT NULL,
  `created` datetime NOT NULL,
  `online` int(1) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` VALUES(3, 'Ma premiere page', 'ma-premiere-page', 'mon contenu', '', '2012-07-06 20:53:51', 1, 0);
INSERT INTO `posts` VALUES(10, 'Mon premier article', 'mon-premier-article', '<p><img class="alignLeft" src="http://www.careerbuilder-corporate.fr/wp-content/uploads/2010/10/facebook.jpg" alt="" width="192" height="72" /></p>\r\n<div id="TheTexte">\r\n<p>Accedat huc suavitas quaedam oportet sermonum atque morum, haudquaquam mediocre condimentum amicitiae. Tristitia autem et in omni re severitas habet illa quidem gravitatem, sed amicitia remissior esse debet et liberior et dulcior et ad omnem comitatem facilitatemque proclivior.</p>\r\n<p>Ut enim benefici liberalesque sumus, non ut exigamus gratiam (neque enim beneficium faeneramur sed natura propensi ad liberalitatem sumus), sic amicitiam non spe mercedis adducti sed quod omnis eius fructus in ipso amore inest, expetendam putamus.</p>\r\n<p>Quae dum ita struuntur, indicatum est apud Tyrum indumentum regale textum occulte, incertum quo locante vel cuius usibus apparatum. ideoque rector provinciae tunc pater Apollinaris eiusdem nominis ut conscius ductus est aliique congregati sunt ex diversis civitatibus multi, qui atrocium criminum ponderibus urgebantur.</p>\r\n</div>', 'post', '2018-07-09 15:13:00', 1, 3);
INSERT INTO `posts` VALUES(11, 'Mon deuxieme article', 'mon-deuxieme-article', '<p><img class="alignLeft" src="http://www.benzinga.com/files/facebook_8.jpg" alt="" width="713" height="439" /></p>\r\n<p>novitates autem si spem adferunt, ut tamquam in herbis non fallacibus fructus appareat, non sunt illae quidem repudiandae, vetustas tamen suo loco conservanda; maxima est enim vis vetustatis et consuetudinis. quin in ipso equo, cuius modo feci mentionem, si nulla res impediat, nemo est, quin eo, quo consuevit, libentius utatur quam intractato et novo. nec vero in hoc quod est animal, sed in iis etiam quae sunt inanima, consuetudo valet, cum locis ipsis delectemur, montuosis etiam et silvestribus, in quibus diutius commorati sumus.<br />postremo ad id indignitatis est ventum, ut cum peregrini ob formidatam haut ita dudum alimentorum inopiam pellerentur ab urbe praecipites, sectatoribus disciplinarum liberalium inpendio paucis sine respiratione ulla extrusis, tenerentur minimarum adseclae veri, quique id simularunt ad tempus, et tria milia saltatricum ne interpellata quidem cum choris totidemque remanerent magistris.<br />iamque lituis cladium concrepantibus internarum non celate ut antea turbidum saeviebat ingenium a veri consideratione detortum et nullo inpositorum vel conpositorum fidem sollemniter inquirente nec discernente a societate noxiorum insontes velut exturbatum e iudiciis fas omne discessit, et causarum legitima silente defensione carnifex rapinarum sequester et obductio capitum et bonorum ubique multatio versabatur per orientales provincias, quas recensere puto nunc oportunum absque mesopotamia digesta, cum bella parthica dicerentur, et aegypto, quam necessario aliud reieci ad tempus.<br />dein syria per speciosam interpatet diffusa planitiem. hanc nobilitat antiochia, mundo cognita civitas, cui non certaverit alia advecticiis ita adfluere copiis et internis, et laodicia et apamia itidemque seleucia iam inde a primis auspiciis florentissimae.<br />fieri, inquam, triari, nullo pacto potest, ut non dicas, quid non probes eius, a quo dissentias. quid enim me prohiberet epicureum esse, si probarem, quae ille diceret? cum praesertim illa perdiscere ludus esset. quam ob rem dissentientium inter se reprehensiones non sunt vituperandae, maledicta, contumeliae, tum iracundiae, contentiones concertationesque in disputando pertinaces indignae philosophia mihi videri solent.<br />harum trium sententiarum nulli prorsus assentior. nec enim illa prima vera est, ut, quem ad modum in se quisque sit, sic in amicum sit animatus. quam multa enim, quae nostra causa numquam faceremus, facimus causa amicorum! precari ab indigno, supplicare, tum acerbius in aliquem invehi insectarique vehementius, quae in nostris rebus non satis honeste, in amicorum fiunt honestissime; multaeque res sunt in quibus de suis commodis viri boni multa detrahunt detrahique patiuntur, ut iis amici potius quam ipsi fruantur.<br />duplexque isdem diebus acciderat malum, quod et theophilum insontem atrox interceperat casus, et serenianus dignus exsecratione cunctorum, innoxius, modo non reclamante publico vigore, discessit.<br />nec vox accusatoris ulla licet subditicii in his malorum quaerebatur acervis ut saltem specie tenus crimina praescriptis legum committerentur, quod aliquotiens fecere principes saevi: sed quicquid caesaris implacabilitati sedisset, id velut fas iusque perpensum confestim urgebatur impleri.<br />inter haec orfitus praefecti potestate regebat urbem aeternam ultra modum delatae dignitatis sese efferens insolenter, vir quidem prudens et forensium negotiorum oppido gnarus, sed splendore liberalium doctrinarum minus quam nobilem decuerat institutus, quo administrante seditiones sunt concitatae graves ob inopiam vini: huius avidis usibus vulgus intentum ad motus asperos excitatur et crebros.<br />eodem tempore serenianus ex duce, cuius ignavia populatam in phoenice celsen ante rettulimus, pulsatae maiestatis imperii reus iure postulatus ac lege, incertum qua potuit suffragatione absolvi, aperte convictus familiarem suum cum pileo, quo caput operiebat, incantato vetitis artibus ad templum misisse fatidicum, quaeritatum expresse an ei firmum portenderetur imperium, ut cupiebat, et cunctum.<br /><br /></p>\r\n<p>&nbsp;</p>', 'post', '2012-07-09 15:16:00', 1, 3);
INSERT INTO `posts` VALUES(12, 'article', 'article', '<p>cncs s v,sd,v sv ,v,,,slddfj jjf jdsfds</p>', 'post', '2012-07-09 17:00:00', 1, 4);
INSERT INTO `posts` VALUES(14, 'blalblal', 'blalblal', '<p>afkzkfoz zj iozfjz fe ezf ze<img class="alignLeft" src="/Djinn/img/2012/07/wallpaper-3_m.jpg" alt="" /></p>', 'page', '2012-07-14 19:01:23', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `role` varchar(60) NOT NULL,
  `created` datetime NOT NULL,
  `lastlogin` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` VALUES(1, 'admin', '', 'bcccc2027e584986416eda18e65ada354011d03f', 'admin', 'admin', 'admin', '0000-00-00 00:00:00', '2012-07-15 10:59:26', 1);
INSERT INTO `users` VALUES(2, 'user', '', '8c9b3fabac0544131dc09056c6d29257b77956d0', 'user', 'user', 'user', '0000-00-00 00:00:00', '2012-07-15 09:37:25', 1);
