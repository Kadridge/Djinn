-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Dim 29 Juillet 2012 à 12:09
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `djinn`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `post_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` VALUES(3, 'audio', 'audio', 7);
INSERT INTO `categories` VALUES(4, 'video', 'video', 0);

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Contenu de la table `comments`
--

INSERT INTO `comments` VALUES(1, 'Voici un commentaire de l''admin', 1, 45);
INSERT INTO `comments` VALUES(10, 'Yippie-Kai-Yay Mother F !', 21, 45);
INSERT INTO `comments` VALUES(12, '<strong>Salut</strong>', 1, 45);
INSERT INTO `comments` VALUES(13, '&lt;strong&gt;fdfs&lt;/strong&gt;', 1, 45);
INSERT INTO `comments` VALUES(14, 'fdfs', 1, 45);
INSERT INTO `comments` VALUES(15, 'Eddy beau gosse !!', 1, 45);
INSERT INTO `comments` VALUES(16, 'salut', 1, 66);
INSERT INTO `comments` VALUES(17, 'coucou', 1, 66);
INSERT INTO `comments` VALUES(18, 'ptit dernier test\r\n', 1, 66);
INSERT INTO `comments` VALUES(19, 'Hey coucou !', 21, 66);
INSERT INTO `comments` VALUES(20, 'miam !', 1, 67);
INSERT INTO `comments` VALUES(21, 'test', 1, 67);
INSERT INTO `comments` VALUES(22, 'fezfez', 1, 67);
INSERT INTO `comments` VALUES(23, 'ccs', 1, 67);
INSERT INTO `comments` VALUES(24, 'Patricia', 1, 67);

-- --------------------------------------------------------

--
-- Structure de la table `medias`
--

CREATE TABLE `medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `crop` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `medias`
--


-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `type` varchar(15) NOT NULL,
  `created` datetime NOT NULL,
  `online` int(1) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `media_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` VALUES(45, 'Mon souhait', 'mon-souhait', '<p>f,sklsf f,sl sf&nbsp;<img class="alignright" src="http://www.frenchinroma.com/wp-content/uploads/2011/09/pizza.jpg" alt="" /></p>', 'post', '2012-07-25 17:28:00', 1, 3, 1, 0, 'Zinedine_Zidane.jpeg', 'uploads/post/filename', 'image/jpeg', 24731, '2012-07-28 21:12:17');
INSERT INTO `posts` VALUES(63, 'je souhaite voire un feu d''artifice', 'je-souhaite-voire-un-feu-d-artifice', '<p>njfdsf</p>', 'post', '2012-07-28 21:16:00', 1, 3, 1, 0, 'new_year_wallpaper_1.jpeg', 'uploads/post/filename', 'image/jpeg', 104396, '2012-07-28 21:17:14');
INSERT INTO `posts` VALUES(64, 'Je souhaite manger', 'je-souhaite-manger', '<p>fsfdsfs</p>', 'post', '2012-07-28 21:17:00', 1, 3, 1, 0, 'wallpaper_3.jpg', 'uploads/post/filename', 'image/jpeg', 51517, '2012-07-28 21:17:38');
INSERT INTO `posts` VALUES(65, 'dqsdqs', 'dqsdqs', '<p>dqsdqd</p>', 'post', '2012-07-28 21:17:00', 1, 3, 1, 0, 'windows_seven_wallpaper_7.jpeg', 'uploads/post/filename', 'image/jpeg', 345665, '2012-07-28 21:17:53');
INSERT INTO `posts` VALUES(66, 'dsqdsq', 'dsqdsq', '<p>dqsdq</p>', 'post', '2012-07-28 21:27:00', 1, 3, 1, 0, 'Amazing_Space_nice_Desktop_Wallpapers_42.jpg', 'uploads/post/filename', 'image/jpeg', 131475, '2012-07-28 21:27:58');
INSERT INTO `posts` VALUES(67, 'Pizza !', 'pizza', '<p>je souheterai manger une pizza !!&nbsp;<img class="alignLeft" src="http://www.3-2-1-pizza.eu/media/3-2-1-history-chicago-style.jpg" alt="" /></p>', 'post', '2012-07-28 22:32:00', 1, 3, 21, 0, 'pizza.jpeg', 'uploads/post/filename', 'image/jpeg', 66955, '2012-07-28 23:55:44');
INSERT INTO `posts` VALUES(68, 'Boire un cocktail sur un lagon', 'boire-un-cocktail-sur-un-lagon', '<p>Boire un cocktail sur un lagon</p>\r\n<p><img class="alignCenter" src="http://www.linternaute.com/voyage/asie/photo/serenite-aux-maldives/image/fenetre-lagon-360635.jpg" alt="" /></p>', 'post', '2012-07-29 00:03:00', 1, 3, 1, 0, 'cocktail.jpeg', 'uploads/post/filename', 'image/jpeg', 111249, '2012-07-29 11:54:07');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `role` varchar(60) NOT NULL DEFAULT 'user',
  `created` datetime NOT NULL,
  `lastlogin` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `dir` varchar(255) NOT NULL DEFAULT 'uploads/user/filename',
  `mimetype` varchar(255) NOT NULL DEFAULT 'image/jpeg',
  `filesize` varchar(11) NOT NULL DEFAULT '2933',
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` VALUES(1, 'admin', '', 'bcccc2027e584986416eda18e65ada354011d03f', 'administrateur', 'administrateur', 'admin', '0000-00-00 00:00:00', '2012-07-29 12:04:30', 1, 'Zinedine_Zidane.jpeg', 'uploads/user/filename', 'image/jpeg', '24731', '2012-07-29 12:04:30');
INSERT INTO `users` VALUES(18, 'user', '', '8c9b3fabac0544131dc09056c6d29257b77956d0', '', '', 'user', '2012-07-24 18:02:12', '0000-00-00 00:00:00', 1, '', '', '', '', '0000-00-00 00:00:00');
INSERT INTO `users` VALUES(21, 'nicolas', '', 'b53ee9a33c25e8d4c0d302051b9f7bce53cd934b', 'Nicolas', 'Chomel', 'admin', '2012-07-26 11:02:38', '2012-07-29 11:41:51', 1, 'brad_pitt.jpeg', 'uploads/user/filename', 'image/jpeg', '25785', '2012-07-29 11:41:51');
