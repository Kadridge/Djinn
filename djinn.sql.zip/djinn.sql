-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Dim 19 Août 2012 à 12:25
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `djinn`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `post_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` VALUES(3, 'audio', 'audio', 2);
INSERT INTO `categories` VALUES(4, 'video', 'video', 0);

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Contenu de la table `comments`
--

INSERT INTO `comments` VALUES(1, 'test', 1, 68, '2012-08-12 20:27:56');
INSERT INTO `comments` VALUES(2, 'njdqkdq', 1, 68, '2012-08-12 20:31:03');
INSERT INTO `comments` VALUES(3, 'fsdfsdfsf', 1, 68, '2012-08-12 20:33:10');
INSERT INTO `comments` VALUES(4, 'dsqdq', 1, 68, '2012-08-13 08:20:18');
INSERT INTO `comments` VALUES(5, 'trop fort', 1, 67, '2012-08-13 21:16:40');
INSERT INTO `comments` VALUES(6, 'test', 1, 70, '2012-08-14 22:30:23');
INSERT INTO `comments` VALUES(7, 'dsfds', 1, 70, '2012-08-14 22:31:17');
INSERT INTO `comments` VALUES(8, 'fdsf', 1, 70, '2012-08-14 22:31:21');
INSERT INTO `comments` VALUES(9, '', 0, 0, '2012-08-15 18:26:20');
INSERT INTO `comments` VALUES(10, '', 0, 0, '2012-08-15 18:26:38');
INSERT INTO `comments` VALUES(11, '', 0, 0, '2012-08-15 18:34:47');
INSERT INTO `comments` VALUES(12, '', 0, 0, '2012-08-15 18:35:24');
INSERT INTO `comments` VALUES(13, 'test commentaire', 1, 1, '2012-08-15 20:24:41');

-- --------------------------------------------------------

--
-- Structure de la table `departements`
--

CREATE TABLE `departements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `numero` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Contenu de la table `departements`
--

INSERT INTO `departements` VALUES(1, 1, 'Bas-Rhin', '67');
INSERT INTO `departements` VALUES(2, 1, 'Haut-Rhin', '68');
INSERT INTO `departements` VALUES(3, 2, 'Dordogne', '24');
INSERT INTO `departements` VALUES(4, 2, 'Gironde', '33');
INSERT INTO `departements` VALUES(5, 2, 'Landes', '40');
INSERT INTO `departements` VALUES(6, 2, 'Lot-et-Garonne', '47');
INSERT INTO `departements` VALUES(7, 2, 'Pyrénées-Atlantiques', '64');
INSERT INTO `departements` VALUES(8, 3, 'Allier', '03');
INSERT INTO `departements` VALUES(9, 3, 'Cantal', '15');
INSERT INTO `departements` VALUES(10, 3, 'Haute-Loire', '43');
INSERT INTO `departements` VALUES(11, 3, 'Puy-de-Dôme', '63');
INSERT INTO `departements` VALUES(12, 4, 'Côte-d''Or', '21');
INSERT INTO `departements` VALUES(13, 4, 'Nièvre', '58');
INSERT INTO `departements` VALUES(14, 4, 'Saône-et-Loire', '71');
INSERT INTO `departements` VALUES(15, 4, 'Yonne', '89');
INSERT INTO `departements` VALUES(16, 5, 'Côtes-d''Armor', '22');
INSERT INTO `departements` VALUES(17, 5, 'Finistère', '29');
INSERT INTO `departements` VALUES(18, 5, 'Ille-et-Vilaine', '35');
INSERT INTO `departements` VALUES(19, 5, 'Morbihan', '56');
INSERT INTO `departements` VALUES(20, 6, 'Cher', '18');
INSERT INTO `departements` VALUES(21, 6, 'Eure-et-Loir', '28');
INSERT INTO `departements` VALUES(22, 6, 'Indre', '36');
INSERT INTO `departements` VALUES(23, 6, 'Indre-et-Loire', '37');
INSERT INTO `departements` VALUES(24, 6, 'Loir-et-Cher', '41');
INSERT INTO `departements` VALUES(25, 6, 'Loiret', '45');
INSERT INTO `departements` VALUES(26, 7, 'Ardennes', '08');
INSERT INTO `departements` VALUES(27, 7, 'Aube', '10');
INSERT INTO `departements` VALUES(28, 7, 'Marne', '51');
INSERT INTO `departements` VALUES(29, 7, 'Haute-Marne', '52');
INSERT INTO `departements` VALUES(30, 8, 'Corse-du-Sud', '2A');
INSERT INTO `departements` VALUES(31, 8, 'Haute-Corse', '2B');
INSERT INTO `departements` VALUES(32, 9, 'Doubs', '25');
INSERT INTO `departements` VALUES(33, 9, 'Jura', '39');
INSERT INTO `departements` VALUES(34, 9, 'Haute-Saône', '70');
INSERT INTO `departements` VALUES(35, 9, 'Territoire de Belfort', '90');
INSERT INTO `departements` VALUES(36, 10, 'Paris', '75');
INSERT INTO `departements` VALUES(37, 10, 'Essonne', '91');
INSERT INTO `departements` VALUES(38, 10, 'Hauts-de-Seine', '92');
INSERT INTO `departements` VALUES(39, 10, 'Seine-Saint-Denis', '93');
INSERT INTO `departements` VALUES(40, 10, 'Seine-et-Marne', '77');
INSERT INTO `departements` VALUES(41, 10, 'Val-de-Marne', '94');
INSERT INTO `departements` VALUES(42, 10, 'Val-d''Oise', '95');
INSERT INTO `departements` VALUES(43, 10, 'Yvelines', '78');
INSERT INTO `departements` VALUES(44, 11, 'Aude', '11');
INSERT INTO `departements` VALUES(45, 11, 'Gard', '30');
INSERT INTO `departements` VALUES(46, 11, 'Hérault', '34');
INSERT INTO `departements` VALUES(47, 11, 'Lozère', '48');
INSERT INTO `departements` VALUES(48, 11, 'Pyrénées-Orientales', '66');
INSERT INTO `departements` VALUES(49, 12, 'Corrèze', '19');
INSERT INTO `departements` VALUES(50, 12, 'Creuse', '23');
INSERT INTO `departements` VALUES(51, 12, 'Haute-Vienne', '87');
INSERT INTO `departements` VALUES(52, 13, 'Meurthe-et-Moselle', '54');
INSERT INTO `departements` VALUES(53, 13, 'Meuse', '55');
INSERT INTO `departements` VALUES(54, 13, 'Moselle', '57');
INSERT INTO `departements` VALUES(55, 13, 'Vosges', '88');
INSERT INTO `departements` VALUES(56, 14, 'Ariège', '09');
INSERT INTO `departements` VALUES(57, 14, 'Aveyron', '12');
INSERT INTO `departements` VALUES(58, 14, 'Haute-Garonne', '31');
INSERT INTO `departements` VALUES(59, 14, 'Gers', '32');
INSERT INTO `departements` VALUES(60, 14, 'Lot', '46');
INSERT INTO `departements` VALUES(61, 14, 'Hautes-Pyrénées', '65');
INSERT INTO `departements` VALUES(62, 14, 'Tarn', '81');
INSERT INTO `departements` VALUES(63, 14, 'Tarn-et-Garonne', '82');
INSERT INTO `departements` VALUES(64, 15, 'Nord', '59');
INSERT INTO `departements` VALUES(65, 15, 'Pas-de-Calais', '62');
INSERT INTO `departements` VALUES(66, 16, 'Calvados', '14');
INSERT INTO `departements` VALUES(67, 16, 'Manche', '50');
INSERT INTO `departements` VALUES(68, 16, 'Orne', '61');
INSERT INTO `departements` VALUES(69, 17, 'Eure', '27');
INSERT INTO `departements` VALUES(70, 17, 'Seine-Maritime', '76');
INSERT INTO `departements` VALUES(71, 18, 'Loire-Atlantique', '44');
INSERT INTO `departements` VALUES(72, 18, 'Maine-et-Loire', '49');
INSERT INTO `departements` VALUES(73, 18, 'Mayenne', '53');
INSERT INTO `departements` VALUES(74, 18, 'Sarthe', '72');
INSERT INTO `departements` VALUES(75, 18, 'Vendée', '85');
INSERT INTO `departements` VALUES(76, 19, 'Aisne', '02');
INSERT INTO `departements` VALUES(77, 19, 'Oise', '60');
INSERT INTO `departements` VALUES(78, 19, 'Somme', '80');
INSERT INTO `departements` VALUES(79, 20, 'Charente', '16');
INSERT INTO `departements` VALUES(80, 20, 'Charente-Maritime', '17');
INSERT INTO `departements` VALUES(81, 20, 'Deux-Sèvres', '79');
INSERT INTO `departements` VALUES(82, 20, 'Vienne', '86');
INSERT INTO `departements` VALUES(83, 21, 'Alpes-de-Haute-Provence', '04');
INSERT INTO `departements` VALUES(84, 21, 'Hautes-Alpes', '05');
INSERT INTO `departements` VALUES(85, 21, 'Alpes-Maritimes', '06');
INSERT INTO `departements` VALUES(86, 21, 'Bouches-du-Rhône', '13');
INSERT INTO `departements` VALUES(87, 21, 'Var', '83');
INSERT INTO `departements` VALUES(88, 21, 'Vaucluse', '84');
INSERT INTO `departements` VALUES(89, 22, 'Ain', '01');
INSERT INTO `departements` VALUES(90, 22, 'Ardèche', '07');
INSERT INTO `departements` VALUES(91, 22, 'Drôme', '26');
INSERT INTO `departements` VALUES(92, 22, 'Isère', '38');
INSERT INTO `departements` VALUES(93, 22, 'Loire', '42');
INSERT INTO `departements` VALUES(94, 22, 'Rhône', '69');
INSERT INTO `departements` VALUES(95, 22, 'Savoie', '73');
INSERT INTO `departements` VALUES(96, 22, 'Haute-Savoie', '74');
INSERT INTO `departements` VALUES(97, 23, 'Guyane', '973');
INSERT INTO `departements` VALUES(98, 23, 'Guadeloupe', '971');
INSERT INTO `departements` VALUES(99, 23, 'Martinique', '972');
INSERT INTO `departements` VALUES(100, 23, 'Réunion', '974');

-- --------------------------------------------------------

--
-- Structure de la table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `likes`
--

INSERT INTO `likes` VALUES(1, 1, 2);
INSERT INTO `likes` VALUES(2, 1, 1);
INSERT INTO `likes` VALUES(3, 18, 1);

-- --------------------------------------------------------

--
-- Structure de la table `medias`
--

CREATE TABLE `medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `crop` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `medias`
--


-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `type` varchar(15) NOT NULL,
  `created` datetime NOT NULL,
  `online` int(1) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `media_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  `comment_count` int(11) NOT NULL,
  `view_count` int(11) NOT NULL,
  `like_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` VALUES(1, 'Boire un cocktail sur un lagon', 'boire-un-cocktail-sur-un-lagon', '<p>cocktail lagon</p>', 'post', '2012-08-15 20:21:00', 1, 3, 1, 0, 'cocktail-2.jpeg', 'uploads/post/filename', 'image/jpeg', 111249, '2012-08-15 20:22:32', 1, 55, 2);
INSERT INTO `posts` VALUES(2, 'couché de soleil', 'couche-de-soleil', '<p>soleil</p>', 'post', '2012-08-15 20:28:00', 1, 3, 1, 0, 'Amazing_Space_nice_Desktop_Wallpapers_42-1.jpg', 'uploads/post/filename', 'image/jpeg', 131475, '2012-08-15 20:28:48', 0, 23, 1);

-- --------------------------------------------------------

--
-- Structure de la table `posts_tags`
--

CREATE TABLE `posts_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `posts_tags`
--

INSERT INTO `posts_tags` VALUES(15, 68, 14);
INSERT INTO `posts_tags` VALUES(16, 67, 14);
INSERT INTO `posts_tags` VALUES(17, 68, 15);
INSERT INTO `posts_tags` VALUES(18, 66, 16);
INSERT INTO `posts_tags` VALUES(19, 65, 16);
INSERT INTO `posts_tags` VALUES(20, 63, 16);
INSERT INTO `posts_tags` VALUES(21, 45, 16);
INSERT INTO `posts_tags` VALUES(22, 68, 16);
INSERT INTO `posts_tags` VALUES(23, 70, 18);
INSERT INTO `posts_tags` VALUES(25, 1, 14);

-- --------------------------------------------------------

--
-- Structure de la table `regions`
--

CREATE TABLE `regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `regions`
--

INSERT INTO `regions` VALUES(1, 'Alsace');
INSERT INTO `regions` VALUES(2, 'Aquitaine');
INSERT INTO `regions` VALUES(3, 'Auvergne');
INSERT INTO `regions` VALUES(4, 'Bourgogne');
INSERT INTO `regions` VALUES(5, 'Bretagne');
INSERT INTO `regions` VALUES(6, 'Centre');
INSERT INTO `regions` VALUES(7, 'Champagne-Ardenne');
INSERT INTO `regions` VALUES(8, 'Corse');
INSERT INTO `regions` VALUES(9, 'Franche-Comté');
INSERT INTO `regions` VALUES(10, 'Île-de-France');
INSERT INTO `regions` VALUES(11, 'Languedoc-Roussillon');
INSERT INTO `regions` VALUES(12, 'Limousin');
INSERT INTO `regions` VALUES(13, 'Lorraine');
INSERT INTO `regions` VALUES(14, 'Midi-Pyrénées');
INSERT INTO `regions` VALUES(15, 'Nord-Pas-de-Calais');
INSERT INTO `regions` VALUES(16, 'Basse-Normandie');
INSERT INTO `regions` VALUES(17, 'Haute-Normandie');
INSERT INTO `regions` VALUES(18, 'Pays de la Loire');
INSERT INTO `regions` VALUES(19, 'Picardie');
INSERT INTO `regions` VALUES(20, 'Poitou-Charentes');
INSERT INTO `regions` VALUES(21, 'Provence-Alpes-Côte d''Azur');
INSERT INTO `regions` VALUES(22, 'Rhône-Alpes');
INSERT INTO `regions` VALUES(23, 'DOM');

-- --------------------------------------------------------

--
-- Structure de la table `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Contenu de la table `tags`
--

INSERT INTO `tags` VALUES(14, 'cocktail', 3);
INSERT INTO `tags` VALUES(15, 'lagon', 1);
INSERT INTO `tags` VALUES(16, 'truc', 5);
INSERT INTO `tags` VALUES(17, 'test', 1);
INSERT INTO `tags` VALUES(18, 'brad pitt', 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `departement_id` int(11) NOT NULL,
  `role` varchar(60) NOT NULL DEFAULT 'user',
  `created` datetime NOT NULL,
  `lastlogin` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT 'avatar.jpg',
  `dir` varchar(255) NOT NULL DEFAULT 'uploads/user/filename',
  `mimetype` varchar(255) NOT NULL DEFAULT 'image/jpeg',
  `filesize` varchar(11) NOT NULL DEFAULT '2933',
  `modified` datetime NOT NULL,
  `facebook_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` VALUES(1, 'admin', '', 'bcccc2027e584986416eda18e65ada354011d03f', 'administrateur', 'administrateur', 0, 'admin', '0000-00-00 00:00:00', '2012-08-18 22:36:32', 1, 'Zinedine_Zidane.jpeg', 'uploads/user/filename', 'image/jpeg', '24731', '2012-08-18 22:36:32', 0);
INSERT INTO `users` VALUES(18, 'user', '', '8c9b3fabac0544131dc09056c6d29257b77956d0', 'jean louis', 'jean louis', 0, 'user', '2012-07-24 18:02:12', '2012-08-18 22:33:34', 1, 'avatar.jpg', 'uploads/user/filename', 'image/jpeg', '2933', '2012-08-18 22:33:34', 0);
INSERT INTO `users` VALUES(21, 'nicolas', '', 'b53ee9a33c25e8d4c0d302051b9f7bce53cd934b', 'Nicolas', 'Chomel', 0, 'admin', '2012-07-26 11:02:38', '2012-07-29 16:09:53', 1, 'brad_pitt-0.jpeg', 'uploads/user/filename', 'image/jpeg', '25785', '2012-07-29 16:09:53', 0);
INSERT INTO `users` VALUES(22, 'Yvelines', '', '28caf29cada81ee073ec08727ca8f18690d1ed7d', '', '', 43, 'user', '2012-08-12 12:44:17', '0000-00-00 00:00:00', 1, 'dfault.jpg', 'uploads/user/filename', 'image/jpeg', '2933', '2012-08-12 12:44:17', 0);
INSERT INTO `users` VALUES(58, 'pouet', 'bchdskbflbdbv45678Gdtc@yopmail.com', 'bcccc2027e584986416eda18e65ada354011d03f', '', '', 0, 'user', '2012-08-12 19:32:54', '0000-00-00 00:00:00', 1, 'dfault.jpg', 'uploads/user/filename', 'image/jpeg', '2933', '2012-08-12 19:34:29', 0);
INSERT INTO `users` VALUES(60, 'test', '', 'ccd0fed1f9816f965c635fa3741b7a894b1a020c', '', '', 0, 'user', '2012-08-18 22:35:19', '2012-08-18 22:35:29', 1, 'avatar.jpg', 'uploads/user/filename', 'image/jpeg', '2933', '2012-08-18 22:35:29', 0);
