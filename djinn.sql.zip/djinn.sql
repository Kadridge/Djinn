-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Jeu 26 Juillet 2012 à 17:35
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `djinn`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `post_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` VALUES(3, 'audio', 'audio', 4);
INSERT INTO `categories` VALUES(4, 'video', 'video', 0);

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `comments`
--

INSERT INTO `comments` VALUES(1, 'Voici un commentaire de l''admin', 1, 45);
INSERT INTO `comments` VALUES(3, 'Lol trop nul ton souhait', 21, 45);

-- --------------------------------------------------------

--
-- Structure de la table `medias`
--

CREATE TABLE `medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `crop` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `medias`
--


-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `type` varchar(15) NOT NULL,
  `created` datetime NOT NULL,
  `online` int(1) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `media_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` VALUES(40, 'Ma page', 'ma-page', '<p><img class="alignLeft" src="/Djinn/img/2012/07/amazing-space-nice-desktop-wallpapers-42.jpg" alt="" /></p>', 'page', '2012-07-25 11:25:58', 1, 0, 0, 0, '', '', '', 0, '0000-00-00 00:00:00');
INSERT INTO `posts` VALUES(45, 'Mon souhait', 'mon-souhait', '<p>f,sklsf f,sl sf&nbsp;<img class="alignright" src="http://www.frenchinroma.com/wp-content/uploads/2011/09/pizza.jpg" alt="" /></p>', 'post', '2012-07-25 17:28:00', 1, 3, 1, 0, 'windows_seven_wallpaper_7.jpeg', 'uploads/post/filename', 'image/jpeg', 345665, '2012-07-25 19:51:52');
INSERT INTO `posts` VALUES(57, 'meio', 'meio', '<p>,kslc</p>', 'post', '2012-07-25 19:37:00', 1, 3, 1, 0, 'new_year_wallpaper_1.jpeg', 'uploads/post/filename', 'image/jpeg', 104396, '2012-07-25 19:37:38');
INSERT INTO `posts` VALUES(59, 'Test wish', 'test-wish', '<p>fnjkfk fs d</p>', 'post', '2012-07-26 11:10:00', 1, 3, 21, 0, 'wallpaper_3.jpg', 'uploads/post/filename', 'image/jpeg', 51517, '2012-07-26 11:10:44');
INSERT INTO `posts` VALUES(60, 'Je souhaite voir Zidane', 'je-souhaite-voir-zidane', '<p>Zidane il est trop beau</p>', 'post', '2012-07-26 16:58:00', 1, 3, 21, 0, 'Zinedine_Zidane.jpeg', 'uploads/post/filename', 'image/jpeg', 24731, '2012-07-26 17:06:35');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `role` varchar(60) NOT NULL DEFAULT 'user',
  `created` datetime NOT NULL,
  `lastlogin` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `dir` varchar(255) NOT NULL DEFAULT 'uploads/user/filename',
  `mimetype` varchar(255) NOT NULL DEFAULT 'image/jpeg',
  `filesize` varchar(11) NOT NULL DEFAULT '2933',
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` VALUES(1, 'admin', '', 'bcccc2027e584986416eda18e65ada354011d03f', 'admin', 'admin', 'admin', '0000-00-00 00:00:00', '2012-07-26 11:15:02', 1, 'Amazing_Space_nice_Desktop_Wallpapers_42.jpg', 'uploads/user/filename', 'image/jpeg', '131475', '2012-07-26 11:15:40');
INSERT INTO `users` VALUES(18, 'user', '', '8c9b3fabac0544131dc09056c6d29257b77956d0', '', '', 'user', '2012-07-24 18:02:12', '0000-00-00 00:00:00', 1, '', '', '', '', '0000-00-00 00:00:00');
INSERT INTO `users` VALUES(21, 'nicolas', '', 'b53ee9a33c25e8d4c0d302051b9f7bce53cd934b', '', '', 'admin', '2012-07-26 11:02:38', '2012-07-26 16:33:52', 1, 'd_fault.jpg', 'uploads/user/filename', 'image/jpeg', '2933', '2012-07-26 16:34:17');
